"use client";

import { useState, useEffect } from 'react';
import { supabase } from '@/utils/supabaseClient';
import { useRouter } from 'next/navigation';
import {
  Plus,
  Edit2,
  Trash2,
  Save,
  X,
  Settings,
  Search,
  Loader2,
} from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

// (ضع كود الترجمة الكامل هنا كما في الملف السابق)
const translations = {
  en: {
    dashboard: 'Dashboard',
    addGame: 'Add Game',
    siteSettings: 'Site Settings',
    // ... أضف كل ترجمات لوحة التحكم
  },
  ar: {
    dashboard: 'لوحة التحكم',
    addGame: 'إضافة لعبة',
    siteSettings: 'إعدادات الموقع',
    // ...
  },
  de: {
    // ...
  },
};

// --- دالة مساعدة لرفع الملفات (من الكود القديم) ---
async function uploadFile(file, bucket) {
  if (!file) return null;
  const fileExt = file.name.split('.').pop();
  const filePath = `public/${uuidv4()}.${fileExt}`;
  const { error: uploadError } = await supabase.storage
    .from(bucket)
    .upload(filePath, file);
  if (uploadError) {
    console.error('Upload error:', uploadError.message);
    return null;
  }
  const { data } = supabase.storage.from(bucket).getPublicUrl(filePath);
  return data.publicUrl;
}
// --- دالة مساعدة لحذف الملفات (من الكود القديم) ---
const getPathFromUrl = (url) => {
  if (!url) return null;
  try {
    const urlObj = new URL(url);
    const parts = urlObj.pathname.split('/game-images/');
    return parts[1] || null;
  } catch (e) {
    console.error('Invalid URL:', url, e);
    return null;
  }
};

export default function DashboardPage({ searchParams }) {
  const lang = searchParams.lang || 'en';
  const t = translations[lang] || translations.en;
  const isRTL = lang === 'ar';
  const router = useRouter();

  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // --- كل حالات لوحة التحكم ---
  const [games, setGames] = useState([]);
  const [allGames, setAllGames] = useState([]); // (يجب تحسين هذا، لكن سننقله كما هو)
  const [editingGame, setEditingGame] = useState(null);
  const [newGame, setNewGame] = useState({
    name: '',
    description: '',
    categories: [],
    languages: [],
    image: '',
    screenshots: [],
    links: { windows: '', mac: '', linux: '', android: '' },
    visits: '',
    rating: '',
    ratingCount: '',
  });
  const [newCategory, setNewCategory] = useState('');
  const [editCategory, setEditCategory] = useState('');
  const [newLanguage, setNewLanguage] = useState('');
  const [editLanguage, setEditLanguage] = useState('');
  const [imageFile, setImageFile] = useState(null);
  const [screenshotFiles, setScreenshotFiles] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  const [dashboardSearchQuery, setDashboardSearchQuery] = useState('');

  const [socialLinks, setSocialLinks] = useState({
    reddit: '',
    telegram: '',
    youtube: '',
    twitter: '',
    email: '',
  });
  const [showSettingsSaved, setShowSettingsSaved] = useState(false);

  // --- التحقق من المصادقة ---
  useEffect(() => {
    const checkUser = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession();
      if (!session) {
        router.push('/login'); // إعادة توجيه
      } else {
        setUser(session.user);
        fetchDashboardData();
      }
    };
    checkUser();
  }, [router]);

  async function fetchDashboardData() {
    setLoading(true);
    // (هذا هو نفس كود جلب البيانات القديم)
    try {
      const { data: gamesData, error: gamesError } = await supabase
        .from('games')
        .select('*')
        .order('created_at', { ascending: false });
      if (gamesError) throw gamesError;
      setGames(gamesData || []);
      setAllGames(gamesData || []);
    } catch (error) {
      console.error('Error fetching games:', error.message);
    }
    // (جلب الإعدادات)
    try {
      const { data: settingsData, error: settingsError } = await supabase
        .from('site_settings')
        .select('social_links')
        .eq('id', 1)
        .single();
      if (settingsData) {
        setSocialLinks(settingsData.social_links);
      }
    } catch (error) {
      console.error('Error fetching settings:', error.message);
    }
    setLoading(false);
  }

  // --- نسخ كل دوال لوحة التحكم (CRUD) من الملف القديم ---
  // (handleAddGame, handleUpdateGame, handleDeleteGame, handleSaveSettings, ...)
  // (handleImageUpload, handleScreenshotsUpload, handleAddCategory, ...)

  // ... (قم بنسخ ولصق جميع الدوال من الملف القديم هنا) ...
  // مثال على دالة واحدة:
  const handleAddGame = async () => {
    // ... (نفس الكود من الملف القديم) ...
    // ...
    if (!newGame.name) return; // (استخدم رسالة خطأ أفضل بدلاً من alert)
    setIsUploading(true);
    // ...
    // بعد النجاح:
    // قم بتحديث الحالة
    fetchDashboardData(); // أسهل طريقة لإعادة المزامنة
    // ... (إعادة تعيين النموذج)
  };
  
  // (يجب نسخ بقية الدوال هنا)

  if (loading || !user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-12 h-12 animate-spin text-purple-400" />
      </div>
    );
  }

  return (
    <div dir={isRTL ? 'rtl' : 'ltr'}>
      {/* أضفنا هيدر بسيط خاص بلوحة التحكم
        أو يمكنك إعادة استخدام <Header />
      */}
      <header className="bg-black/30 p-4 sticky top-0 z-40">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold text-purple-400">
            {t.dashboard}
          </h1>
          <button
            onClick={() => router.push('/')}
            className="text-gray-300 hover:text-white"
          >
            {t.back}
          </button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* --- بداية كود لوحة التحكم (منسوخ من الملف القديم) ---
          (هذا هو نفس كود عرض لوحة التحكم من <body> القديم)
        */}
        <div className="space-y-6">
          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-purple-500/20">
            <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
              <Plus className="w-6 h-6" />
              {t.addGame}
            </h2>
            {/* (نموذج إضافة اللعبة كاملاً هنا) */}
            {/* ... */}
            <button
              onClick={handleAddGame}
              disabled={isUploading}
              className="mt-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-2 rounded-lg"
            >
              {isUploading ? '...' : t.addGame}
            </button>
          </div>

          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-purple-500/20">
            <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
              <Settings className="w-6 h-6" />
              {t.siteSettings}
            </h2>
            {/* (نموذج إعدادات الموقع كاملاً هنا) */}
            {/* ... */}
          </div>

          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-purple-500/20">
            <h2 className="text-2xl font-bold text-white mb-4">
              {t.dashboard}
            </h2>
            {/* (شريط البحث الخاص بلوحة التحكم) */}
            {/* ... */}
            {/* (قائمة الألعاب للتعديل والحذف) */}
            {/* ... */}
          </div>
        </div>
        {/* --- نهاية كود لوحة التحكم --- */}
      </main>
    </div>
  );
}